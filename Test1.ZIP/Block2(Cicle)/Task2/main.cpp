#include <iostream>

using namespace std;

int main()
{
    int s = 0;
    for (int k=-3; k<5; k++)
    {
        s = s + k;
    }
    cout << s;
    return 0;
}
